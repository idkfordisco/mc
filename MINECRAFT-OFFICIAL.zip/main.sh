iiww chmod +x go
./go